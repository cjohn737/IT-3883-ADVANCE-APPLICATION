
COIN_VALUES = {
    "penny": 0.01,
    "nickel": 0.05,
    "dime": 0.10,
    "quarter": 0.25
}

def normalize_denomination(word):

    #Here I'm going to convert plural coin names to singular for matching in dictionary. Special case: 'pennies' -> 'penny'

    if word == "pennies":
        return "penny"
    elif word.endswith("s"):
        return word[:-1]
    return word

def parse_coin_input(sentence):
    # Here I'm using parses, an English sentence describing coin amounts, calculates the total dollar value."""
    total = 0.0
    sentence = sentence.lower()  # Make case-insensitive
    parts = sentence.split(" and ")  # Split on 'and'

    for part in parts:
        tokens = part.strip().split(" ")  # Split into [number, coin]
        if len(tokens) == 2:
            quantity = int(tokens[0])
            denom = normalize_denomination(tokens[1])
            if denom in COIN_VALUES:
                total += quantity * COIN_VALUES[denom]
    return round(total, 2)  # Round to 2 decimal places

# Example usage with test cases
if __name__ == "__main__":
    test_inputs = [
        "1 penny and 2 nickels",
        "4 dimes and 7 quarters",
        "1 quarter and 3 pennies",
        "21 pennies and 17 dimes and 52 quarters",
        "95 dimes and 73 quarters and 22 nickels and 36 pennies",
        "1 nickel and 17 quarters",
        "21 nickels and 15 pennies",
        "1 dime and 1 nickel and 1 penny and 1 quarter"
    ]

    for input_str in test_inputs:
        result = parse_coin_input(input_str)
        print(f"{input_str} -> {result}")